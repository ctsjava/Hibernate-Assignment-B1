package com.niladri.movies;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;

@Entity
public class Category 
{
	@Id
	private int category_id;
	private String name;
	private String last_update;
	
	@OneToMany
	@JoinTable(name="film_category",joinColumns= {@JoinColumn(name="category_id")},inverseJoinColumns= {@JoinColumn(name="film_id")})
	List<Film> films = new ArrayList<Film>();

	public int getCategory_id() {
		return category_id;
	}

	public void setCategory_id(int category_id) {
		this.category_id = category_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLast_update() {
		return last_update;
	}

	public void setLast_update(String last_update) {
		this.last_update = last_update;
	}

	public List<Film> getFilms() {
		return films;
	}

	public void setFilms(List<Film> films) {
		this.films = films;
	}
	
	
}
