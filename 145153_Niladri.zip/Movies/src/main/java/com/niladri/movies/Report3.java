package com.niladri.movies;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

public class Report3 {

	public static void main(String[] args) 
	{
		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session ses = sf.openSession();
		
		CriteriaBuilder cb = ses.getCriteriaBuilder();

		CriteriaQuery<Category> q = cb.createQuery(Category.class);
		Root<Category> root = q.from(Category.class);
		q.select(root).where(cb.equal(root.get("name"), "Action"));
		Query<Category> query = ses.createQuery(q);
		List<Category> rows = query.getResultList();
		for (Category category : rows) {
			for(Film film:category.getFilms())
			{
				System.out.print(film.getFilm_id()+"\t");
				System.out.print(film.getTitle()+"\t");
				System.out.print(film.getDescription()+"\t");
				System.out.println(category.getName());
			}
			
		}
	}

}
