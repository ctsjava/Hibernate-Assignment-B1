package com.sb;

import util.*;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

public class FetchLanguage {

public static void main(String[] args) {
		
	SessionFactory sf = HibernateUtil.getSessionFactory();
	Session ses = sf.openSession();
	
	CriteriaBuilder cb = ses.getCriteriaBuilder();

	CriteriaQuery<Language> q = cb.createQuery(Language.class);
	Root<Language> root = q.from(Language.class);
	q.select(root).where(cb.equal(root.get("name"), "English"));
	Query<Language> query = ses.createQuery(q);
	List<Language> rows = query.getResultList();	

		for (Language lang : rows) {
			for(Film film:lang.getFilms())
			{
				System.out.print(film.getFilm_id()+"\t");
				System.out.print(film.getTitle()+"\t");
				System.out.print(film.getDescription()+"\t");
				System.out.println(lang.getName());
			}
				
		} 
	
	}
}

