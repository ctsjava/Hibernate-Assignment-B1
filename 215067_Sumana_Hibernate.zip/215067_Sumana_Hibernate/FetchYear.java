package com.sb;

import util.HibernateUtil;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

public class FetchYear {

public static void main(String[] args) {
		

	SessionFactory sf = HibernateUtil.getSessionFactory();
	Session ses = sf.openSession();

	CriteriaBuilder cb = ses.getCriteriaBuilder();

	
	
	CriteriaQuery<Film> q = cb.createQuery(Film.class);
	Root<Film> root = q.from(Film.class);
	q.select(root).where(cb.equal(root.get("release_year"), 2006));
	Query<Film> query = ses.createQuery(q);
	List<Film> films = query.getResultList();
	for (Film film : films) 
		{
		System.out.print(film.getFilm_id()+"\t");
		System.out.print(film.getTitle()+"\t");
		System.out.print(film.getDescription()+"\t");
		System.out.println(film.getRelease_year());
		}
	}
	
}
