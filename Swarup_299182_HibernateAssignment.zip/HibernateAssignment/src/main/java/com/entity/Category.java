package com.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQuery;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@NamedQuery(name = "category_action", query = "from Category where name like 'action'")
public class Category {
	
	public Category() {
		// TODO Auto-generated constructor stub
	}

	public Category(int category_id, String name, Date last_update) {
		
		this.category_id = category_id;
		this.name = name;
		this.last_update = last_update;
	}
	
	@Id
	private int category_id;
	private String name;
	@Temporal (TemporalType.TIMESTAMP)
	private Date last_update;
	
	@ManyToMany(cascade=CascadeType.ALL, fetch=FetchType.EAGER)
	@JoinTable(name="film_category",joinColumns= {@JoinColumn(name="category_id")},inverseJoinColumns= {@JoinColumn(name="film_id")})
	
	private List<Movies> movies = new ArrayList<Movies>();
	
	public List<Movies> getFilms() {
		return movies;
	}

	public void setFilms(List<Movies> movies) {
		this.movies = movies;
	}

	public int getCategory_id() {
		return category_id;
	}

	public void setCategory_id(int category_id) {
		this.category_id = category_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getLast_update() {
		return last_update;
	}

	public void setLast_update(Date last_update) {
		this.last_update = last_update;
	}

	public List<Movies> getMovies() {
		return movies;
	}

	public void setMovies(List<Movies> movies) {
		this.movies = movies;
	}

}
