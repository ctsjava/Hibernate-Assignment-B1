package com.entity;

import org.hibernate.query.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import java.util.List;

import com.config.HibernateUtil;

public class FetchMovies {

	public static void main(String[] args) {

		SessionFactory sf = HibernateUtil.getSessionFactory();

		Session ses = sf.openSession();
	
		Query<Film> q1 = ses.createNamedQuery("release_year_2006", Film.class);

		List<Film> films = q1.list();

		for (Film film : films) {
			System.out.println("Film Id: "+film.getFilm_id());
			System.out.println("Film name: "+film.getTitle());
			System.out.println("Film description: "+film.getDescription());
			System.out.println("Film release year: "+film.getRelease_year());
			System.out.println("-----------------------------");
		}

		
		
			}
}
